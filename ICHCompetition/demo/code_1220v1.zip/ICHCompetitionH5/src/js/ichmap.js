
$(()=>{
    'use strict';

    $('#yuko-mask-iknow').on('touchend', function () {
        $('#yuko-mask').fadeOut(280);
    });
    
});