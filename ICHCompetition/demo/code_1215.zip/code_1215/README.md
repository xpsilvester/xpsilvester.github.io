### 一、下载依赖包
```
npm install
```
### 二、打包
```
gulp
```

### 三、更新日志

#### 12.13
1. 添加learnPark.html页面
2. enroll、uploadVideo_1 更新‘活动规则’按钮交互效果
3. enroll 图片路径更新

#### 12.14
1. 添加cheer.html、cheer_1.html、cheerGuide.html(弹窗，需要在前两个页面调用)、attention.html
2. learnPark.html 页面与后台对接代码更新

#### 12.15
1.添加index.html 页面
2.learnPark.html 页面 报名按钮修改 视频修改 增加播放按钮状态 